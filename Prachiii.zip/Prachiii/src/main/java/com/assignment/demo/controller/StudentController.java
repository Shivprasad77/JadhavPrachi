package com.assignment.demo.controller;
import java.util.*;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.assignment.demo.exception.NotFound;
import com.assignment.demo.Entity.NewStudents;
import com.assignment.demo.Repository.StudentsRepository;


@RestController
@RequestMapping("/api/users")


public class StudentController{
	@Autowired
	private StudentsRepository userRepository;
	public List<NewStudents> getAllUser(){
		return this.userRepository.findAll();
	}
	 @GetMapping("/{id}")
	    public NewStudents getUserById(@PathVariable(value = "id") long userId) {
	        return this.userRepository.findById(userId)
	            .orElseThrow(() -> new NotFound("Student not found with id :" + userId));
	    }
	@PostMapping
	public NewStudents createUser(@RequestBody NewStudents user) {
		return this.userRepository.save(user);
	}
	@PutMapping("/{id}")
    public NewStudents updateUser(@RequestBody NewStudents user, @PathVariable("id") long userId) {
		NewStudents existingUser = this.userRepository.findById(userId)
            .orElseThrow(() -> new NotFound("Student not found with id :" + userId));
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());
        return this.userRepository.save(existingUser);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity < NewStudents > deleteUser(@PathVariable("id") long userId){
		NewStudents existingUser = this.userRepository.findById(userId)
		            .orElseThrow(() -> new NotFound("Student not found with id :" + userId));
		 this.userRepository.delete(existingUser);
		return ResponseEntity.ok().build();
	}
   
}
	

